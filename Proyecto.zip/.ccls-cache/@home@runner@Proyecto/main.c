#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <unistd.h>
#include "hashmap.h"
#include "list.h"
/////////////////////////////ESTRUCTURAS///////////////////////////////

typedef struct Usuario{
  char rut[100];
  char tipo_usuario[100];
  List *horario_usuario;
  char ramo[100];
  List *lista_feedBack;
} Usuario;

typedef struct Horario {
  char dia[100];
  List *reservado;
  List *disponible;
} Horario;

typedef struct Sala {
  char numeroSala[100];
  List *horario_sala;
} Sala;

/////////////////////////FUNCIONES VARIAS//////////////////////////////

void imprimir_opcion(char *opcion) {
  printf("\033[1;32m║\033[0m %-39s      \033[1;32m║\n", opcion);
}

void menu() {
  printf("\n\033[1;32m╔══════════════════════════════════════════════╗\n");
  printf("\033[1;32m║             SERVICIO ESTUDIANTIL             \033[1;32m║\n");
  printf("\033[1;32m╠──────────────────────────────────────────────╣\n");
  imprimir_opcion("1. Registrar usuario");
  imprimir_opcion("2. Importar horario salas");
  imprimir_opcion("3. Reservar");
  imprimir_opcion("4. Cancelar reserva");
  imprimir_opcion("5. Mostrar todas salas");
  imprimir_opcion("6. Mostrar horarios de tutores");
  imprimir_opcion("7. FeedBack");
  printf("\033[1;32m║\033[1;31m 0. SALIR                                     \033[0m\033[1;32m║\n");
  printf("\033[1;32m╚══════════════════════════════════════════════╝\033[0m\n");
  printf("\033[1;37mIngrese una opción: \033[0m");
}

void leerCadena101(char cadena[101]) {
  while (getchar() != '\n');
  scanf("%100[^\n]", cadena);
}

////////////////////////FUNCIONES PRINCIPALES//////////////////////////
//Funcion Registrar Usuario.

Horario *crearHorario(const char dia[]){
  getchar();
  Horario *nuevoHorario = (Horario *)malloc(sizeof(Horario));
  if (nuevoHorario == NULL) {
    perror("Error al crear el horario");
    exit(EXIT_FAILURE);
  }
  strcpy(nuevoHorario->dia, dia);
  
  nuevoHorario->reservado = createList();
  nuevoHorario->disponible = createList();
  
  printf("Ingrese los horarios reservados (separados por espacios): ");
  char horariosReservados[100];
  leerCadena101(horariosReservados);
  char *token = strtok(horariosReservados, " ");
  while (token != NULL) {
    pushBack(nuevoHorario->reservado, strdup(token));
    token = strtok(NULL, " ");
  }
  
  printf("Ingrese los horarios disponibles (separados por espacios): ");
  char horariosDisponibles[100];
  leerCadena101(horariosDisponibles);
  token = strtok(horariosDisponibles, " ");
  while (token != NULL) {
    pushBack(nuevoHorario->disponible, strdup(token));
    token = strtok(NULL, " ");
  }
  
  return nuevoHorario;
}

void registrarUsuario(HashMap *mapa_estudiante, HashMap *mapa_tutor) {
  getchar();
  int opcion;
  printf("\n¿Qué tipo de usuario eres?\n");
  printf(" 1. Tutor\n");
  printf(" 2. Estudiante\n");
  printf("\n\033[1;37mIngrese una opción: \033[0m");
  scanf("%d", &opcion);
  
  Usuario *nuevoUsuario = (Usuario *)malloc(sizeof(Usuario));
  
  printf("\nIngrese el rut del usuario: ");
  leerCadena101(nuevoUsuario->rut);
  
  if (opcion == 1) {
    // Tutor
    strcpy(nuevoUsuario->tipo_usuario, "Tutor");
    printf("Ingrese el ramo de especialización del tutor: ");
    leerCadena101(nuevoUsuario->ramo);
    
    nuevoUsuario->horario_usuario = createList();
    nuevoUsuario->lista_feedBack = createList();
    
    int numDias;
    printf("Ingrese el número de días disponibles: ");
    scanf("%d", &numDias);
    
    for (int i = 0; i < numDias; i++){
      char dia[100];
      printf("Ingrese el día %d: ", i + 1);
      leerCadena101(dia);
      
      Horario *nuevoHorario = crearHorario(dia);
      
      pushBack(nuevoUsuario->horario_usuario, nuevoHorario);
    }
    insertMap(mapa_tutor, nuevoUsuario->rut, nuevoUsuario);

    printf("\n\033[38;2;255;165;0mUsuario ingresado correctamente.\033[0m\n");
  }else{
    // Estudiante
    strcpy(nuevoUsuario->tipo_usuario, "Estudiante");
    insertMap(mapa_estudiante, nuevoUsuario->rut, nuevoUsuario);
    printf("\n\033[38;2;255;165;0mUsuario ingresado correctamente.\033[0m\n");
  }
}

//════════════════════════════════════════════════════════════════════
//Funcion Importar horario de salas.

void importarSalas(List *lista_salas, const char *nombreArchivo){
  FILE *archivo = fopen(nombreArchivo, "r");

  if (archivo == NULL) {
    perror("Error al abrir el archivo");
    exit(EXIT_FAILURE);
  }

  char linea[256];
  char numeroSala[100];
  char dia[100];
  char *token;

  while (fgets(linea, sizeof(linea), archivo) != NULL){
    
    Sala *nuevaSala = (Sala *)malloc(sizeof(Sala));
    List *horarios = createList();

    token = strtok(linea, " ");
    strcpy(numeroSala, token);
    strcpy(nuevaSala->numeroSala, numeroSala);

    token = strtok(NULL, " ");
    strcpy(dia, token);
    while ((token = strtok(NULL, " \n")) != NULL){
      if (strcmp(token, "listaReservado") == 0){
        
        Horario *nuevoHorario = (Horario *)malloc(sizeof(Horario));
        strcpy(nuevoHorario->dia, dia);

        nuevoHorario->reservado = createList();
        nuevoHorario->disponible = createList();
        while ((token = strtok(NULL, " \n")) != NULL && strcmp(token, "listaDisponible") != 0){
          pushBack(nuevoHorario->reservado, strdup(token));
        }

        while ((token = strtok(NULL, " \n")) != NULL && strcmp(token, "listaReservado") != 0){
          pushBack(nuevoHorario->disponible, strdup(token));
        }
        pushBack(horarios, nuevoHorario);
      }
    }
    nuevaSala->horario_sala = horarios;
    pushBack(lista_salas, nuevaSala);
  }
  printf("\033[38;2;255;165;0m\n¡Se ha importado el horario de las salas correctamente!\033[0m\n");
  fclose(archivo);
}

//════════════════════════════════════════════════════════════════════
//Funcion Reservar.

int verificarDisponibilidad(List *horarios, const char *dia, const char *horario){
  List *horarioData = firstList(horarios);
  while (horarioData != NULL){
    Horario *h = (Horario *)horarioData;
    if (strcmp(h->dia, dia) == 0){
      List *disponibleData = firstList(h->disponible);
      while (disponibleData != NULL){
        char *horaDisponible = (char *)disponibleData;
        if (strcmp(horaDisponible, horario) == 0){
          return 1;
        }
        disponibleData = nextList(h->disponible);
      }
    }
    horarioData = nextList(horarios);
  }
  return 0;
}

void reservarHorario(List *horarios, const char *dia, const char *horario){
  void *horarioData = firstList(horarios);
  while (horarioData != NULL){
    Horario *h = (Horario *)horarioData;
    if (strcmp(h->dia, dia) == 0){
      
      void *disponibleData = firstList(h->disponible);
      while (disponibleData != NULL){
        
        char *horaDisponible = (char *)disponibleData;
        if (strcmp(horaDisponible, horario) == 0){
          
          pushBack(h->reservado, strdup(horaDisponible));
          popCurrent(h->disponible);
          return;
        }
        disponibleData = nextList(h->disponible);
      }
    }
    horarioData = nextList(horarios);
  }
}

void reservarSala(HashMap *mapa_estudiante, HashMap *mapa_tutor, List *lista_salas){
  getchar();
  
  char rutEstudiante[100];
  printf("Ingrese su rut como estudiante: ");
  leerCadena101(rutEstudiante);

  Pair *estudiantePair = searchMap(mapa_estudiante, rutEstudiante);
  if (estudiantePair == NULL) {
    printf("No se encontró al estudiante con el rut '%s'.\n", rutEstudiante);
    return;
  }

  Usuario *estudiante = (Usuario *)estudiantePair->value;

  int opcion;
  printf("¿Desea reservar con o sin tutor?\n");
  printf(" 1. Con tutor\n");
  printf(" 2. Sin tutor\n");
  printf("Ingrese una opción: ");
  scanf("%d", &opcion);

  if (opcion == 1) {
    getchar();
    char rutTutor[100];
    printf("Ingrese el rut del tutor: ");
    leerCadena101(rutTutor);

    Pair *tutorPair = searchMap(mapa_tutor, rutTutor);
    if (tutorPair == NULL) {
      printf("No se encontró al tutor con el rut '%s'.\n", rutTutor);
      return;
    }
    Usuario *tutor = (Usuario *)tutorPair->value;

    char numeroSala[100];
    char dia[100];
    char horario[100];

    printf("Ingrese el número de la sala: ");
    leerCadena101(numeroSala);
    printf("Ingrese el día de la reserva: ");
    leerCadena101(dia);
    printf("Ingrese el horario de la reserva: ");
    leerCadena101(horario);

    Sala *sala = NULL;
    void *salaData = firstList(lista_salas);
    while (salaData != NULL) {
      Sala *s = (Sala *)salaData;
      if (strcmp(s->numeroSala, numeroSala) == 0) {
        sala = s;
        break;
      }
      salaData = nextList(lista_salas);
    }
    
    if (sala == NULL) {
      printf("No se encontró la sala con el número '%s'.\n", numeroSala);
      return;
    }
    
    if (verificarDisponibilidad(tutor->horario_usuario, dia, horario) && verificarDisponibilidad(sala->horario_sala, dia, horario)) {
      
      reservarHorario(tutor->horario_usuario, dia, horario);
      reservarHorario(sala->horario_sala, dia, horario);
      printf("Reserva realizada con éxito.\n");
    } else {
      printf("No hay disponibilidad en el horario solicitado.\n");
    }

  } else if (opcion == 2) {
    char numeroSala[100];
    char dia[100];
    char horario[100];

    printf("Ingrese el número de la sala: ");
    leerCadena101(numeroSala);
    printf("Ingrese el día de la reserva: ");
    leerCadena101(dia);
    printf("Ingrese el horario de la reserva: ");
    leerCadena101(horario);

       
    Sala *sala = NULL;
    void *salaData = firstList(lista_salas);
    while (salaData != NULL) {
      Sala *s = (Sala *)salaData;
      if (strcmp(s->numeroSala, numeroSala) == 0) {
        sala = s;
        break;
      }
      salaData = nextList(lista_salas);
    }

    if (sala == NULL) {
      printf("No se encontró la sala con el número '%s'.\n", numeroSala);
      return;
    }
    
    if (verificarDisponibilidad(sala->horario_sala, dia, horario)) {
      reservarHorario(sala->horario_sala, dia, horario);
      printf("\033[38;2;255;165;0mReserva realizada con éxito.\033[0m\n");
    } else {
      printf("No hay disponibilidad en el horario solicitado.\n");
    }

  } else {
    printf("Opción no válida.\n");
  }
}

//════════════════════════════════════════════════════════════════════
//Funcion Cancelar Reserva.

void liberarHorario(List *horarios, const char *dia, const char *horario) {
  void *horarioData = firstList(horarios);
  while (horarioData != NULL) {
    Horario *h = (Horario *)horarioData;
    if (strcmp(h->dia, dia) == 0) {
      void *reservadoData = firstList(h->reservado);
      while (reservadoData != NULL) {
        char *horaReservada = (char *)reservadoData;
        if (strcmp(horaReservada, horario) == 0) {
          pushBack(h->disponible, strdup(horaReservada));
          popCurrent(h->reservado);
          return;
        }
        reservadoData = nextList(h->reservado);
      }
    }
    horarioData = nextList(horarios);
  }
}

void cancelarReserva(HashMap *mapa_estudiante, HashMap *mapa_tutor, List *lista_salas) {
  getchar();

  char rutEstudiante[100];
  printf("Ingrese su rut como estudiante: ");
  leerCadena101(rutEstudiante);

    
  Pair *estudiantePair = searchMap(mapa_estudiante, rutEstudiante);
  if (estudiantePair == NULL) {
    printf("No se encontró al estudiante con el rut '%s'.\n", rutEstudiante);
    return;
  }
  Usuario *estudiante = (Usuario *)estudiantePair->value;

    
  int opcion;
  printf("¿Desea cancelar la reserva con o sin tutor?\n");
  printf(" 1. Con tutor\n");
  printf(" 2. Sin tutor\n");
  printf("Ingrese una opción: ");
  scanf("%d", &opcion);
  
  if (opcion == 1) {
    getchar();
    char rutTutor[100];
    printf("Ingrese el rut del tutor: ");
    leerCadena101(rutTutor);

    
    Pair *tutorPair = searchMap(mapa_tutor, rutTutor);
    if (tutorPair == NULL) {
      printf("No se encontró al tutor con el rut '%s'.\n", rutTutor);
      return;
    }

    Usuario *tutor = (Usuario *)tutorPair->value;

    
    char numeroSala[100];
    char dia[100];
    char horario[100];

    printf("Ingrese el número de la sala: ");
    leerCadena101(numeroSala);
    printf("Ingrese el día de la reserva: ");
    leerCadena101(dia);
    printf("Ingrese el horario de la reserva: ");
    leerCadena101(horario);

    Sala *sala = NULL;
    void *salaData = firstList(lista_salas);
    while (salaData != NULL) {
      Sala *s = (Sala *)salaData;
      if (strcmp(s->numeroSala, numeroSala) == 0) {
        sala = s;
        break;
      }
      salaData = nextList(lista_salas);
    }

    if (sala == NULL) {
      printf("No se encontró la sala con el número '%s'.\n", numeroSala);
      return;
    }

    if (verificarDisponibilidad(tutor->horario_usuario, dia, horario) && verificarDisponibilidad(sala->horario_sala, dia, horario)) {
      printf("No existe una reserva con los datos proporcionados.\n");
    } else {
      liberarHorario(tutor->horario_usuario, dia, horario);
      liberarHorario(sala->horario_sala, dia, horario);
      printf("Reserva cancelada con éxito.\n");
    }

  } else if (opcion == 2) {
    char numeroSala[100];
    char dia[100];
    char horario[100];

    printf("Ingrese el número de la sala: ");
    leerCadena101(numeroSala);
    printf("Ingrese el día de la reserva: ");
    leerCadena101(dia);
    printf("Ingrese el horario de la reserva: ");
    leerCadena101(horario);

        
    Sala *sala = NULL;
    void *salaData = firstList(lista_salas);
    while (salaData != NULL) {
      Sala *s = (Sala *)salaData;
      if (strcmp(s->numeroSala, numeroSala) == 0) {
        sala = s;
        break;
      }
      salaData = nextList(lista_salas);
    }

    if (sala == NULL) {
      printf("No se encontró la sala con el número '%s'.\n", numeroSala);
      return;
    }

        
    if (verificarDisponibilidad(sala->horario_sala, dia, horario)) {
      printf("No existe una reserva con los datos proporcionados.\n");
    } else {
            
      liberarHorario(sala->horario_sala, dia, horario);
      printf("\033[38;2;255;165;0mReserva cancelada con éxito.\033[0m\n");
    }
  
  } else {
    printf("Opción no válida.\n");
  }
}

//════════════════════════════════════════════════════════════════════
//Funcion Mostrar todas las salas.

void mostrarSalas(List *lista_salas){
  void *salaNode = firstList(lista_salas);
  while (salaNode != NULL){
    printf("\033[38;2;255;165;0m═════════════════════════════════════════════\033[0m\n");
    Sala *sala = (Sala *)salaNode;
    printf("Número de Sala: %s\n", sala->numeroSala);
    
    printf("\n\033[1;36mHorarios:\033[0m\n");
    void *horarioNode = firstList(sala->horario_sala);
    while (horarioNode != NULL){
      Horario *horario = (Horario *)horarioNode;
      printf("Día: %s\n", horario->dia);
      printf("Reservado: ");
      
      void *reservadoNode = firstList(horario->reservado);
      while (reservadoNode != NULL) {
        char *horarioReservado = (char *)reservadoNode;
        printf("%s ", horarioReservado);
        reservadoNode = nextList(horario->reservado);
      }
      
      printf("\nDisponible: ");
      void *disponibleNode = firstList(horario->disponible);
        
      while (disponibleNode != NULL){
        char *horarioDisponible = (char *)disponibleNode;
        printf("%s ", horarioDisponible);
        disponibleNode = nextList(horario->disponible);
      }
      printf("\n");
      horarioNode = nextList(sala->horario_sala);
    }

    printf("\n");
    salaNode = nextList(lista_salas);
  }
}

//════════════════════════════════════════════════════════════════════
//Funcion mostrar todos los tutores de un ramo de especializacion.

void mostrarTutores(HashMap *mapa_tutor){
  getchar();
  char ramoBuscado[101];

  printf("Ingrese el ramo de especialización:\n");
  leerCadena101(ramoBuscado);
  
  Pair *tutorPair = firstMap(mapa_tutor);
  while (tutorPair != NULL){
    printf("\033[38;2;255;165;0m═════════════════════════════════════════════\033[0m\n");
    Usuario *tutor = (Usuario *)tutorPair->value;
    if (strcmp(tutor->ramo, ramoBuscado) == 0) {
      printf("\nRamo de especialización: %s\n", tutor->ramo);
      printf("Rut: %s\n", tutor->rut);
      printf("Tipo de usuario: %s\n", tutor->tipo_usuario);

      printf("\n\033[1;36mHorarios:\033[0m\n");
      void *horarioNode = firstList(tutor->horario_usuario);
      while (horarioNode != NULL) {
        Horario *horario = (Horario *)horarioNode;
        printf("\033[38;2;255;165;0mDía: %s\033[0m\n", horario->dia);
        
        printf("-Reservado: ");
        void *reservadoNode = firstList(horario->reservado);
        while (reservadoNode != NULL) {
          char *horarioReservado = (char *)reservadoNode;
          printf("%s ", horarioReservado);

          reservadoNode = nextList(horario->reservado);
        }

        printf("\n-Disponible: ");
        void *disponibleNode = firstList(horario->disponible);
        while (disponibleNode != NULL) {
          char *horarioDisponible = (char *)disponibleNode;
          printf("%s ", horarioDisponible);
          disponibleNode = nextList(horario->disponible);
        }
        printf("\n\n");
        
        horarioNode = nextList(tutor->horario_usuario);
      }
    }
    
    tutorPair = nextMap(mapa_tutor);
  }
}

//════════════════════════════════════════════════════════════════════
//Funcion Feedback de tutor.

void mostrarPromediosFeedback(Usuario *tutor) {
  printf("\nPromedios de respuestas del tutor %s:\n", tutor->rut);

  List *valoracionNode = firstList(tutor->lista_feedBack);
  while (valoracionNode != NULL) {
    float *valoracion = (float *)valoracionNode;
    printf("%.2f\n", *valoracion);
    valoracionNode = nextList(tutor->lista_feedBack);
  }
  printf("\n");
}

void feedBack(HashMap *mapa_tutor) {
  char rutTutor[100];
  printf("Ingrese el rut del tutor: ");
  leerCadena101(rutTutor);

  Pair *tutorPair = searchMap(mapa_tutor, rutTutor);
  if (tutorPair == NULL) {
    printf("No se encontró al tutor con el rut '%s'.\n", rutTutor);
    return;
  }

  Usuario *tutor = (Usuario *)tutorPair->value;
  printf("\n\033[1;32m¡Bienvenido a la encuesta de feedback para el tutor %s!\033[0m\n\n", tutor->rut);

  char *preguntas[] = {
  "¿En qué medida el tutor resolvió adecuadamente tus dudas?",
  "¿Qué tan clara fue la explicación proporcionada por el tutor?",
  "¿Cómo calificarías la claridad en la comunicación durante la tutoría?",
  "¿Cómo percibiste la paciencia del tutor durante la tutoría?",
  "¿En qué medida el tutor estuvo disponible cuando lo necesitabas?",
  "¿Qué opinas sobre los métodos de enseñanza utilizados por el tutor?",
  "¿Cómo calificarías la calidad de la comunicación con el tutor?",
  "¿En qué medida el tutor se adaptó a tus necesidades durante la tutoría?"
};

  char *opciones[] = {
  "1: Insatisfactorio.",
  "2: Regular.",
  "3: Aceptable.",
  "4: Bueno.",
  "5: Excelente."
};

  int totalRespuestas = 0;
  int contadorRespuestas = 0;

  for (int i = 0; i < 8; i++) {
    printf("\033[1;35m%s\033[0m\n", preguntas[i]);
    for (int j = 0; j < 5; j++) {
      printf("\033[1;37m%s\033[0m\n", opciones[j]);
    }
  
    int respuesta;
    printf("Ingrese su respuesta (1-5): ");
    scanf("%d", &respuesta);
  
    if (respuesta >= 1 && respuesta <= 5) {
      totalRespuestas += respuesta;
      contadorRespuestas++;
    } else {
      printf("Respuesta no válida. Por favor, ingrese un número entre 1 y 5.\n");
      i--;
    }
  }

  float promedio = (float)totalRespuestas / contadorRespuestas;
  float *nuevoPromedio = (float *)malloc(sizeof(float));
  *nuevoPromedio = promedio;
  pushBack(tutor->lista_feedBack, nuevoPromedio);
  
  printf("\033[1;32m\nPromedio de respuestas: %.2f\033[0m\n", promedio);

  char cadena[50];
  snprintf(cadena, sizeof(cadena), "%.2f", promedio);
  printf("Promedio de respuestas guardado en la lista personal del tutor %s.\n", tutor->rut);
  mostrarPromediosFeedback(tutor);
}

//════════════════════════════════════════════════════════════════════
/////////////////////////////MAIN///////////////////////////////////
int main(){
  int opcion;
  HashMap *mapa_estudiante = createMap(1000);
  HashMap *mapa_tutor = createMap(1000);
  List *lista_salas = createList();
  while (true) {
    menu();
    scanf("%d", &opcion);
    switch (opcion) {
    case 1:
      registrarUsuario(mapa_estudiante,mapa_tutor);
      break;
    case 2:
      importarSalas(lista_salas,"horarios.csv");
      break;
    case 3:
      reservarSala(mapa_estudiante,mapa_tutor,lista_salas);
      break;
    case 4:
      cancelarReserva(mapa_estudiante,mapa_tutor,lista_salas);
      break;
    case 5:
      mostrarSalas(lista_salas);
      break;
    case 6:
      mostrarTutores(mapa_tutor);
      break;
    case 7:
      feedBack(mapa_tutor);
      break;
    case 0:
      printf("\033[1;31m\nSALISTE DEL MENÚ\033[0m\n");
      return 0;
    default:
      printf("\033[1;31m\nIngrese una opción válida.\033[0m\n");
      break;
    }
  }
  return 0;
}