**Descripción:**
  - En este proyecto nosotros realizaremos un programa capaz de ayudar a los estudiantes que necesiten un apoyo en sus notas a traves de un sistema de salas de estudios y tutores, la aplicacion permite registrar el usuario y decidir si aquel usuario es estudiante o tutor, tambien permite importar un archivo csv que contiene informacion de las salas (de modo de ejemplo), permite reservar las salas de estudio con o sin tutor, luego el cancelar la reserva anteriormente hecha, permite mostrar todas las salas con sus horarios y si estas estan reservadas o disponibles, mostrar el horario de tutores para ayudar al usuario a tomar una desicion y finalmente el feedback con el cual el usuario podra evaluar al tutor respondiendo una series de preguntas para ver si el servicio fue satisfactorio o no.

**Compilar y ejecutar:**
https://github.com/JOAQUINCASTRO/Proyecto
cd gestor-de-tareas
gcc main.c funciones_tareas.c -o gestor
./gestor

**Consejos**
  -Se recomienda al usuario importar el horario de las salas antes de realizar cualquier operacion para que no haya problemas al querer reservar o mostrar salas y horarios.
  
-----------------------------------------------------------------   
**Funcionalidades:**

  **Funcionando correctamente:**
      - "menu": Esta funcion se encarga de mostrar pantalla el menu al usuario para que este trabaje con el.
      
      - "registrarUsuario": Esta funcion se encarga de pedirle los datos al usuario dependiendo si el que se esta inscribiendo es Tutor o Estudiante.
      
      - "importarSalas" Esta funcion se encarga de importar un archivo csv el cual contiene informacion acerca de los horarios de las salas y si estas estan disponibles o reservadas. El formato del csv es:
      numeroSala dia listaReservado horario 1... listaDisponible horario 1...
      
      - "reservarSala": Esta funcion se encarga de reservar la sala en un horario solo si esta tiene ese horario disponible, tambien se asegura de preguntar si la reserva que quiere hacer el usuario es con o sin tutor.
      
      - "cancelarReserva": Esta funcion se encarga de cancelar la reserva del horario, la sala y/o el tutor anteriormente hecha, esto cambia el estado de todas estas cosas de "Reservado" a "Disponible".
      
      - "mostrarSalas": Esta funcion se encarga de mostrar por pantalla todas las salas y sus horarios ademas de mostrar si estos horarios estan "Reservado" o "Disponibles".
      
      - "mostrarTutores": Esta funcion se encarga de mostrar por pantalla todos los tutores de un mismo codigo de ramo y sus horarios "Reservado" y "Disponibles" esto se consigue pidiendole al usuario que ingrese el codigo de los tutores que quiere ver.
      
      -"feedBack": Esta funcion se encarga de hacer una serie de preguntar al usuario que tienen que ver con la calidad de servicio que dio el tutor para con el usuario, este tendra que responderlas del 1 al 5 dependiendo de lo que crea y se sacara el promedio para asi darle una evaluacion al tutor.
      
  **Detalles:**
      -Es necesario a veces ingresar 2 veces el dato para que la aplicacion lo lea.
      -Se pueden presentar problemas debido a la falta de condicionales(cosas minimas).
      
------------------------------------------------------------------
**Aportes:** 

  **Javier Morales**
      - Hizo la funcion "registrarUsuario"
      - Hizo la funcion "reservarSala"
      - Hizo la funcion "cancelarReserva"
      - **Auto-evaluación**: 3 (Aporte excelente).

  **Matias Ruiz**
      - Ayudo con la logica general del proyecto.
      - Hizo la funcion "mostrarSalas"
      - Hizo la funcion "mostrarTutores"
      - **Auto-evaluación**: 3 (Aporte excelente).
      
  **Joaquin Castro**
      - Hizo la funcion "feedBack"
      - Hizo la funcion "importarSalas"
      - Hizo la funcion "menu"
      - **Auto-evaluación**: 3 (Aporte excelente).